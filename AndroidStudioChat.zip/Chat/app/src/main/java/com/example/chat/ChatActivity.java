package com.example.chat;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatActivity extends AppCompatActivity
{
    private String userID, username, profileImage, currentuserID ;

    private TextView Username, LastSeen ;
    private CircleImageView ProfileImage ;
    private ImageButton sendMessage, sendFiles ;
    private EditText newMessage ;

    private Toolbar toolbar ;

    private final List<Messages> messagesList = new ArrayList<>();
    private LinearLayoutManager linearLayoutManager ;
    private MessagesAdapter messagesAdapter ;
    private RecyclerView messages ;

    private FirebaseAuth auth ;
    private DatabaseReference rootReference ;
    private Uri uri ;
    private StorageTask upload ;

    private String currentTime, currentDate, checker="", URL="" ;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        userID = Objects.requireNonNull(Objects.requireNonNull(getIntent().getExtras()).get("UserID")).toString() ;
        username = Objects.requireNonNull(getIntent().getExtras().get("Username")).toString() ;
        profileImage = Objects.requireNonNull(getIntent().getExtras().get("ProfileImage")).toString() ;

        auth = FirebaseAuth.getInstance() ;
        currentuserID = Objects.requireNonNull(auth.getCurrentUser()).getUid() ;

        rootReference = FirebaseDatabase.getInstance().getReference() ;

        toolbar = findViewById(R.id.chat_toolbar );
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar() ;
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowCustomEnabled(true);

        LayoutInflater layoutInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert layoutInflater != null;
        View actionBarView = layoutInflater.inflate(R.layout.chat_bar, null) ;
        actionBar.setCustomView(actionBarView);

        InitializeFields() ;

        DisplayLastSeen();

        Username.setText(username);
        Picasso.get().load(profileImage).placeholder(R.drawable.profile_image).into(ProfileImage);

        sendMessage.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                SendMessage();
            }
        });

        sendFiles.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                CharSequence[] options = new CharSequence[]
                        {
                                "Image",
                                "PDF document",
                                "MS-Word document",
                        } ;

                AlertDialog.Builder builder = new AlertDialog.Builder(ChatActivity.this) ;
                builder.setTitle("File Type") ;

                builder.setItems(options, new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        if(which==0)
                        {
                            checker = "image" ;

                            Intent intent = new Intent() ;
                            intent.setAction(Intent.ACTION_GET_CONTENT) ;
                            intent.setType("image/*") ;
                            startActivityForResult(Intent.createChooser(intent, "Select Image"),0);

                        }

                        if(which==1)
                        {
                            checker = "pdf" ;
                        }

                        if(which==2)
                        {
                            checker = "docx" ;
                        }
                    }
                });
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 0 && resultCode == RESULT_OK && data!=null && data.getData()!=null)
        {
            uri = data.getData() ;
            StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Images") ;

            String senderRef = "Messages/" +currentuserID +"/" +userID ;
            String receiverRef = "Messages/"+userID+"/"+currentuserID ;

            String messageKey = rootReference.child("Messages").child(currentuserID).child(userID).push().getKey() ;

            assert messageKey != null;
            StorageReference filePath = storageReference.child(messageKey + ".jpg") ;
            upload = filePath.putFile(uri) 
        }


    }

    @Override
    protected void onStart()
    {
        super.onStart();

        rootReference.child("Messages").child(currentuserID).child(userID).addChildEventListener(new ChildEventListener()
        {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s)
            {
                Messages message = dataSnapshot.getValue(Messages.class) ;
                messagesList.add(message) ;
                messagesAdapter.notifyDataSetChanged();
                messages.smoothScrollToPosition(Objects.requireNonNull(messages.getAdapter()).getItemCount());
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s)
            {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot)
            {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s)
            {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });
    }

    @Override
    protected void onStop()
    {
        super.onStop();

        messagesList.clear();
        messagesAdapter.notifyDataSetChanged();
    }

    private void InitializeFields()
    {
        Username = findViewById(R.id.custom_username) ;
        LastSeen = findViewById(R.id.custom_last_seen) ;
        ProfileImage = findViewById(R.id.custom_profile_image) ;
        sendMessage = findViewById(R.id.chat_send_message) ;
        newMessage = findViewById(R.id.chat_new_message) ;
        sendFiles = findViewById(R.id.chat_send_file) ;

        messagesAdapter = new MessagesAdapter(messagesList) ;
        messages = findViewById(R.id.chat_messages);
        linearLayoutManager = new LinearLayoutManager(this) ;
        messages.setLayoutManager(linearLayoutManager);
        messages.setAdapter(messagesAdapter);

        Calendar calendar = Calendar.getInstance() ;
        SimpleDateFormat date = new SimpleDateFormat("MMM dd, yyyy") ;
        SimpleDateFormat time = new SimpleDateFormat("hh:mm a") ;
        currentDate = date.format(calendar.getTime()) ;
        currentTime = time.format(calendar.getTime()) ;
    }

    private void DisplayLastSeen()
    {
        rootReference.child("Users").child(userID).addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if(dataSnapshot.hasChild("State"))
                {
                    String state = Objects.requireNonNull(dataSnapshot.child("State").child("State").getValue()).toString() ;
                    String date = Objects.requireNonNull(dataSnapshot.child("State").child("Date").getValue()).toString() ;
                    String time = Objects.requireNonNull(dataSnapshot.child("State").child("Time").getValue()).toString() ;

                    if(state.equals("Online"))
                        LastSeen.setText(state);

                    else
                        LastSeen.setText("Last Seen : " + date + " " +time);
                }

                else
                {
                    LastSeen.setText(R.string.offline);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });
    }

    private void SendMessage()
    {
        String message = newMessage.getText().toString() ;
        
        if(TextUtils.isEmpty(message))
            Toast.makeText(this, "Message cannot be empty", Toast.LENGTH_SHORT).show();

        else
        {
            String senderRef = "Messages/" +currentuserID +"/" +userID ;
            String receiverRef = "Messages/"+userID+"/"+currentuserID ;

            String messageKey = rootReference.child("Messages").child(currentuserID).child(userID).push().getKey() ;

            HashMap messageText = new HashMap() ;
            messageText.put("Message", message) ;
            messageText.put("Type", "Text") ;
            messageText.put("From", currentuserID) ;
            messageText.put("To", userID) ;
            messageText.put("Time", currentTime) ;
            messageText.put("Date", currentDate) ;


            HashMap messageDetails = new HashMap() ;
            messageDetails.put(senderRef + "/" + messageKey, messageText) ;
            messageDetails.put(receiverRef + "/"+messageKey, messageText) ;

            rootReference.updateChildren(messageDetails).addOnCompleteListener(new OnCompleteListener()
            {
                @Override
                public void onComplete(@NonNull Task task)
                {
                    if(!task.isSuccessful())
                        Toast.makeText(ChatActivity.this, "Error", Toast.LENGTH_SHORT).show();

                    newMessage.setText("");

                }
            });
        }
    }
}
