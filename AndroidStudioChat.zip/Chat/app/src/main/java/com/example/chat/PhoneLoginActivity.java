package com.example.chat;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class PhoneLoginActivity extends AppCompatActivity
{
    private Button sendVerificationCodeButton, verifyButton ;
    private EditText phoneNumber, verificationCode ;

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks callbacks ;
    private String verificationID ;
    private PhoneAuthProvider.ForceResendingToken resendToken ;
    private FirebaseAuth auth ;
    private DatabaseReference usersReference ;

    private ProgressDialog loadingBar ;

    @Override
    protected void onCreate(final Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_login);

        auth = FirebaseAuth.getInstance() ;
        usersReference = FirebaseDatabase.getInstance().getReference().child("Users") ;

        InitializeFields() ;

        loadingBar = new ProgressDialog(this) ;

        sendVerificationCodeButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                String number = phoneNumber.getText().toString();

                if (TextUtils.isEmpty(number))
                    Toast.makeText(PhoneLoginActivity.this, "Please enter your phone number", Toast.LENGTH_SHORT).show();

                else
                {
                    loadingBar.setTitle("Verifying phone number");
                    loadingBar.setMessage("Please wait while we authenticate your phone");
                    loadingBar.setCanceledOnTouchOutside(false);
                    loadingBar.show();

                    PhoneAuthProvider.getInstance().verifyPhoneNumber(number, 60, TimeUnit.SECONDS, PhoneLoginActivity.this, callbacks);

                }
            }
        });

        verifyButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                sendVerificationCodeButton.setVisibility(View.INVISIBLE);
                phoneNumber.setVisibility(View.INVISIBLE) ;

                verifyButton.setVisibility(View.VISIBLE);
                verificationCode.setVisibility(View.VISIBLE) ;

                String code = verificationCode.getText().toString() ;

                if(TextUtils.isEmpty(code))
                    Toast.makeText(PhoneLoginActivity.this, "Please enter verification code", Toast.LENGTH_SHORT).show();

                else
                {

                    loadingBar.setTitle("Verifying code");
                    loadingBar.setMessage("Please wait while we verify the code");
                    loadingBar.setCanceledOnTouchOutside(false);
                    loadingBar.show();

                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationID, code);
                    signInWithPhoneAuthCredential(credential);
                }
            }
        });

        callbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks()
        {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential)
            {
                signInWithPhoneAuthCredential(phoneAuthCredential);
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e)
            {
                loadingBar.dismiss();

                Toast.makeText(PhoneLoginActivity.this, "Invalid phone number. Make sure to include your country code", Toast.LENGTH_SHORT).show();

                sendVerificationCodeButton.setVisibility(View.VISIBLE);
                phoneNumber.setVisibility(View.VISIBLE) ;

                verifyButton.setVisibility(View.INVISIBLE);
                verificationCode.setVisibility(View.INVISIBLE) ;
            }

            @Override
            public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken token)
            {
                verificationID = verificationId;
                resendToken = token;

                loadingBar.dismiss();

                Toast.makeText(PhoneLoginActivity.this, "Verification code has been sent to your phone", Toast.LENGTH_SHORT).show();

                sendVerificationCodeButton.setVisibility(View.INVISIBLE);
                phoneNumber.setVisibility(View.INVISIBLE) ;

                verifyButton.setVisibility(View.VISIBLE);
                verificationCode.setVisibility(View.VISIBLE) ;
            }
        };
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential)
    {
        auth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>()
        {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task)
            {
                if(task.isSuccessful())
                {
                    String userID = Objects.requireNonNull(auth.getCurrentUser()).getUid();
                    String deviceToken = FirebaseInstanceId.getInstance().getToken();

                    usersReference.child(userID).child("DeviceToken").setValue(deviceToken).addOnCompleteListener(new OnCompleteListener<Void>()
                    {
                        @Override
                        public void onComplete(@NonNull Task<Void> task)
                        {
                            if (task.isSuccessful())
                            {
                                SendUserToMainActivity();
                                Toast.makeText(PhoneLoginActivity.this, "You are now logged in", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                            }
                        }
                    });
                }

                else
                {
                    String message = Objects.requireNonNull(task.getException()).toString() ;
                    Toast.makeText(PhoneLoginActivity.this, "Error : " + message, Toast.LENGTH_SHORT).show();
                }
            }
         });
    }

    private void SendUserToMainActivity()
    {
        Intent mainIntent = new Intent(PhoneLoginActivity.this, MainActivity.class) ;
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK) ;
        startActivity(mainIntent) ;
    }

    private void InitializeFields()
    {
        sendVerificationCodeButton = findViewById(R.id.send_verification_code_button) ;
        verifyButton = findViewById(R.id.verify_button) ;
        phoneNumber = findViewById(R.id.phone_number) ;
        verificationCode = findViewById(R.id.verification_code) ;
    }
}
