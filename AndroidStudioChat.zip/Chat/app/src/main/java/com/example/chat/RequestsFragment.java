package com.example.chat;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class RequestsFragment extends Fragment
{
    private  View requestsView ;
    private RecyclerView requestsList ;

    private DatabaseReference requestsReference, usersReference, contactsReference ;
    private FirebaseAuth auth ;

    private String currentUserID ;

    public RequestsFragment()
    {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        auth = FirebaseAuth.getInstance() ;
        currentUserID = Objects.requireNonNull(auth.getCurrentUser()).getUid() ;
        requestsReference = FirebaseDatabase.getInstance().getReference().child("Requests");
        usersReference = FirebaseDatabase.getInstance().getReference().child("Users") ;
        contactsReference = FirebaseDatabase.getInstance().getReference().child("Contacts") ;

        requestsView = inflater.inflate(R.layout.fragment_requests, container, false);

        requestsList = requestsView.findViewById(R.id.requests_list) ;
        requestsList.setLayoutManager(new LinearLayoutManager(getContext()));

        return  requestsView ;
    }

    @Override
    public void onStart()
    {
        super.onStart();

        FirebaseRecyclerOptions<Contacts> options = new FirebaseRecyclerOptions.Builder<Contacts>().setQuery(requestsReference.child(currentUserID), Contacts.class).build() ;

        FirebaseRecyclerAdapter<Contacts, RequestsViewHolder> adapter = new FirebaseRecyclerAdapter<Contacts, RequestsViewHolder>(options)
        {
            @Override
            protected void onBindViewHolder(@NonNull final RequestsViewHolder holder, int position, @NonNull Contacts model)
            {
                holder.itemView.findViewById(R.id.accept_button).setVisibility(View.VISIBLE);
                holder.itemView.findViewById(R.id.decline_button).setVisibility(View.VISIBLE);

                final String userID = getRef(position).getKey() ;

                final DatabaseReference typeReference  = getRef(position).child("Type").getRef() ;

                typeReference.addValueEventListener(new ValueEventListener()
                {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                    {
                        if (dataSnapshot.exists())
                        {
                            String type = Objects.requireNonNull(dataSnapshot.getValue()).toString();

                            if (type.equals("Received"))
                            {
                                assert userID != null;
                                usersReference.child(userID).addValueEventListener(new ValueEventListener()
                                {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                                    {
                                        final String username = Objects.requireNonNull(dataSnapshot.child("Username").getValue()).toString();
                                        final String status = Objects.requireNonNull(dataSnapshot.child("Status").getValue()).toString();
                                        holder.Username.setText(username);
                                        holder.Status.setText(status);

                                        if (dataSnapshot.hasChild("ProfileImage"))
                                        {
                                            final String profileImage = Objects.requireNonNull(dataSnapshot.child("ProfileImage").getValue()).toString();
                                            Picasso.get().load(profileImage).placeholder(R.drawable.profile_image).into(holder.ProfileImage);
                                        }

                                        holder.AcceptButton.setOnClickListener(new View.OnClickListener()
                                        {
                                            @Override
                                            public void onClick(View v)
                                            {
                                                contactsReference.child(currentUserID).child(userID).child("Type").setValue("Saved").addOnCompleteListener(new OnCompleteListener<Void>()
                                                {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task)
                                                    {
                                                        if (task.isSuccessful())
                                                            contactsReference.child(userID).child(currentUserID).child("Type").setValue("Saved").addOnCompleteListener(new OnCompleteListener<Void>()
                                                            {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Void> task)
                                                                {
                                                                    if (task.isSuccessful())
                                                                        requestsReference.child(currentUserID).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
                                                                        {
                                                                            @Override
                                                                            public void onComplete(@NonNull Task<Void> task)
                                                                            {
                                                                                if (task.isSuccessful())
                                                                                    requestsReference.child(userID).child(currentUserID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
                                                                                    {
                                                                                        @Override
                                                                                        public void onComplete(@NonNull Task<Void> task)
                                                                                        {
                                                                                            if (task.isSuccessful())
                                                                                                Toast.makeText(getContext(), "Contact saved", Toast.LENGTH_SHORT).show();
                                                                                        }
                                                                                    });
                                                                            }
                                                                        });
                                                                }
                                                            });
                                                    }
                                                });
                                            }
                                        });

                                        holder.DeclineButton.setOnClickListener(new View.OnClickListener()
                                        {
                                            @Override
                                            public void onClick(View v)
                                            {
                                                requestsReference.child(currentUserID).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
                                                {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task)
                                                    {
                                                        if (task.isSuccessful())
                                                            requestsReference.child(userID).child(currentUserID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
                                                            {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Void> task)
                                                                {
                                                                    if (task.isSuccessful())
                                                                        Toast.makeText(getContext(), "Request deleted", Toast.LENGTH_SHORT).show();
                                                                }
                                                            });
                                                    }
                                                });
                                            }
                                        });
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError)
                                    {

                                    }
                                });
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError)
                    {

                    }
                });
            }

            @NonNull
            @Override
            public RequestsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
            {
                View view = LayoutInflater.from(getContext()).inflate(R.layout.users_display_layout, parent,false) ;
                return new RequestsViewHolder(view);
            }
        };

        requestsList.setAdapter(adapter);
        adapter.startListening();
    }

    public static class RequestsViewHolder extends RecyclerView.ViewHolder
    {
        TextView Username, Status ;
        CircleImageView ProfileImage ;
        Button AcceptButton, DeclineButton ;

        public RequestsViewHolder(@NonNull View itemView)
        {
            super(itemView);

            Username = itemView.findViewById(R.id.username) ;
            Status = itemView.findViewById(R.id.status) ;
            ProfileImage = itemView.findViewById(R.id.profile_image) ;
            AcceptButton = itemView.findViewById(R.id.accept_button) ;
            DeclineButton = itemView.findViewById(R.id.decline_button) ;

        }
    }
}

