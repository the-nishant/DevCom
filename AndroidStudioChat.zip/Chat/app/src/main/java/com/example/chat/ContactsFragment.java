package com.example.chat;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ContactsFragment extends Fragment
{
    private  View contactsView ;
    private RecyclerView contactsList ;

    private DatabaseReference contactsListReference, usersReference ;
    private FirebaseAuth auth ;

    private String currentUserID ;

    public ContactsFragment()
    {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        auth = FirebaseAuth.getInstance() ;
        currentUserID = Objects.requireNonNull(auth.getCurrentUser()).getUid() ;
        contactsListReference = FirebaseDatabase.getInstance().getReference().child("Contacts").child(currentUserID) ;
        usersReference = FirebaseDatabase.getInstance().getReference().child("Users") ;

        contactsView = inflater.inflate(R.layout.fragment_contacts, container, false);

        contactsList = contactsView.findViewById(R.id.contacts_list) ;
        contactsList.setLayoutManager(new LinearLayoutManager(getContext()));

        return contactsView ;
    }

    @Override
    public void onStart()
    {
        super.onStart();

        FirebaseRecyclerOptions options = new FirebaseRecyclerOptions.Builder<Contacts>().setQuery(contactsListReference, Contacts.class).build() ;

        final FirebaseRecyclerAdapter<Contacts, ContactsViewHolder> adapter = new FirebaseRecyclerAdapter<Contacts, ContactsViewHolder>(options)
        {
            @Override
            protected void onBindViewHolder(@NonNull final ContactsViewHolder holder, int position, @NonNull Contacts model)
            {
                String userID = getRef(position).getKey() ;
                assert userID != null;
                usersReference.child(userID).addValueEventListener(new ValueEventListener()
                {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                    {
                        if(dataSnapshot.exists())
                        {
                            if(dataSnapshot.hasChild("State"))
                            {
                                String state = Objects.requireNonNull(dataSnapshot.child("State").child("State").getValue()).toString() ;
                                String date = Objects.requireNonNull(dataSnapshot.child("State").child("Date").getValue()).toString() ;
                                String time = Objects.requireNonNull(dataSnapshot.child("State").child("Time").getValue()).toString() ;

                                if(state.equals("Online"))
                                    holder.OnlineDot.setVisibility(View.VISIBLE);

                                else
                                    holder.OnlineDot.setVisibility(View.INVISIBLE);
                            }

                            else
                            {
                                holder.OnlineDot.setVisibility(View.INVISIBLE);
                            }


                            String username = Objects.requireNonNull(dataSnapshot.child("Username").getValue()).toString();
                            String status = Objects.requireNonNull(dataSnapshot.child("Status").getValue()).toString();
                            holder.Username.setText(username);
                            holder.Status.setText(status);


                            if (dataSnapshot.hasChild("ProfileImage"))
                            {
                                String profileImage = Objects.requireNonNull(dataSnapshot.child("ProfileImage").getValue()).toString();
                                Picasso.get().load(profileImage).placeholder(R.drawable.profile_image).into(holder.ProfileImage);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError)
                    {

                    }
                });
            }

            @NonNull
            @Override
            public ContactsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
            {
                View view = LayoutInflater.from(getContext()).inflate(R.layout.users_display_layout, parent,false) ;
                return new ContactsViewHolder(view);
            }
        };

        contactsList.setAdapter(adapter);
        adapter.startListening();
    }

    public static class ContactsViewHolder extends RecyclerView.ViewHolder
    {
        TextView Username, Status ;
        CircleImageView ProfileImage ;
        ImageView OnlineDot ;

        public ContactsViewHolder(@NonNull View itemView)
        {
            super(itemView);

            Username = itemView.findViewById(R.id.username) ;
            Status = itemView.findViewById(R.id.status) ;
            ProfileImage = itemView.findViewById(R.id.profile_image) ;
            OnlineDot = itemView.findViewById(R.id.online_status) ;

        }
    }
}
