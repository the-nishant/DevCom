package com.example.chat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class VisitProfileActivity extends AppCompatActivity
{
    private String userID, currentUserID, currentState ;

    private CircleImageView visitProfileImage ;
    private TextView visitUsername, visitStatus ;
    private Button sendRequestButton, declineButton ;

    private DatabaseReference usersReference, requestsReference, contactsReference, notificaationsReference ;
    private FirebaseAuth auth ;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit_profile);

        auth = FirebaseAuth.getInstance() ;
        usersReference = FirebaseDatabase.getInstance().getReference().child("Users") ;
        requestsReference = FirebaseDatabase.getInstance().getReference().child("Requests") ;
        contactsReference = FirebaseDatabase.getInstance().getReference().child("Contacts") ;
        notificaationsReference = FirebaseDatabase.getInstance().getReference().child("Notifications") ;

        userID = Objects.requireNonNull(Objects.requireNonNull(getIntent().getExtras()).get("UserID")).toString() ;
        currentUserID = Objects.requireNonNull(auth.getCurrentUser()).getUid() ;
        currentState = "new" ;

        InitializeFields() ;

        RetrieveUserInfo() ;

    }

    private void RetrieveUserInfo()
    {
        usersReference.child(userID).addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if(dataSnapshot.exists())
                {
                    String username = Objects.requireNonNull(dataSnapshot.child("Username").getValue()).toString() ;
                    String status = Objects.requireNonNull(dataSnapshot.child("Status").getValue()).toString() ;
                    visitUsername.setText(username);
                    visitStatus.setText(status);

                    if(dataSnapshot.hasChild("ProfileImage"))
                    {
                        String profileImage = Objects.requireNonNull(dataSnapshot.child("ProfileImage").getValue()).toString() ;
                        Picasso.get().load(profileImage).placeholder(R.drawable.profile_image).into(visitProfileImage);
                    }

                    ManageChatRequest() ;

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        }) ;
    }

    private void ManageChatRequest()
    {
        requestsReference.child(currentUserID).addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if(dataSnapshot.hasChild(userID))
                {
                    String type = Objects.requireNonNull(dataSnapshot.child(userID).child("Type").getValue()).toString();

                    if(type.equals("Sent"))
                    {
                        currentState = "sent" ;
                        sendRequestButton.setText(R.string.cancel_request);
                    }

                    else if(type.equals("Received"))
                    {
                        currentState = "received";
                        sendRequestButton.setText(R.string.accept);

                        declineButton.setVisibility(View.VISIBLE);
                        declineButton.setEnabled(true);
                        declineButton.setOnClickListener(new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View v)
                            {
                                CancelRequest();
                            }
                        });
                    }
                }

                else
                {
                    contactsReference.child(currentUserID).addListenerForSingleValueEvent(new ValueEventListener()
                    {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                        {
                            if(dataSnapshot.hasChild(userID))
                            {
                                currentState = "friends" ;
                                sendRequestButton.setText(R.string.remove_contact);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError)
                        {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        }) ;

        if(!currentUserID.equals(userID))
        {
            sendRequestButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    sendRequestButton.setEnabled(false);

                    if(currentState.equals("new"))
                        SendRequest() ;

                    if(currentState.equals("sent"))
                        CancelRequest() ;

                    if(currentState.equals("received"))
                        AcceptRequest() ;

                    if(currentState.equals("friends"))
                        RemoveContact() ;
                }
            });
        }
        else
            sendRequestButton.setVisibility(View.INVISIBLE);
    }

    private void RemoveContact()
    {
        contactsReference.child(currentUserID).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
        {
            @Override
            public void onComplete(@NonNull Task<Void> task)
            {
                if(task.isSuccessful())
                    contactsReference.child(userID).child(currentUserID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
                    {
                        @Override
                        public void onComplete(@NonNull Task<Void> task)
                        {
                            if(task.isSuccessful())
                            {
                                sendRequestButton.setEnabled(true);
                                currentState = "new";
                                sendRequestButton.setText(R.string.send_request);

                                declineButton.setEnabled(false);
                                declineButton.setVisibility(View.INVISIBLE);
                            }
                        }
                    }) ;
            }
        }) ;
    }

    private void AcceptRequest()
    {
        contactsReference.child(currentUserID).child(userID).child("Type").setValue("Saved").addOnCompleteListener(new OnCompleteListener<Void>()
        {
            @Override
            public void onComplete(@NonNull Task<Void> task)
            {
                if(task.isSuccessful())
                {
                    contactsReference.child(userID).child(currentUserID).child("Type").setValue("Saved").addOnCompleteListener(new OnCompleteListener<Void>()
                    {
                        @Override
                        public void onComplete(@NonNull Task<Void> task)
                        {
                            if(task.isSuccessful())
                            {
                                requestsReference.child(currentUserID).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
                                {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task)
                                    {
                                        if(task.isSuccessful())
                                        {
                                            requestsReference.child(userID).child(currentUserID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
                                            {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task)
                                                {
                                                    if(task.isSuccessful())
                                                    {
                                                        sendRequestButton.setEnabled(true);
                                                        sendRequestButton.setText(R.string.remove_contact);
                                                        currentState = "friends" ;

                                                        declineButton.setVisibility(View.INVISIBLE);
                                                        declineButton.setEnabled(false);

                                                    }
                                                }
                                            }) ;
                                        }
                                    }
                                }) ;
                            }
                        }
                    });
                }
            }
        });
    }

    private void CancelRequest()
    {
        requestsReference.child(currentUserID).child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
        {
            @Override
            public void onComplete(@NonNull Task<Void> task)
            {
                if(task.isSuccessful())
                    requestsReference.child(userID).child(currentUserID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>()
                    {
                        @Override
                        public void onComplete(@NonNull Task<Void> task)
                        {
                            if(task.isSuccessful())
                            {
                                sendRequestButton.setEnabled(true);
                                currentState = "new";
                                sendRequestButton.setText(R.string.send_request);

                                declineButton.setEnabled(false);
                                declineButton.setVisibility(View.INVISIBLE);
                            }
                        }
                    }) ;
            }
        }) ;
    }

    private void SendRequest()
    {
        requestsReference.child(currentUserID).child(userID).child("Type").setValue("Sent").addOnCompleteListener(new OnCompleteListener<Void>()
        {
            @Override
            public void onComplete(@NonNull Task<Void> task)
            {
                if(task.isSuccessful())
                {
                    requestsReference.child(userID).child(currentUserID).child("Type").setValue("Received").addOnCompleteListener(new OnCompleteListener<Void>()
                    {
                        @Override
                        public void onComplete(@NonNull Task<Void> task)
                        {
                            if(task.isSuccessful())
                            {

                                HashMap<String, String> requestNotification = new HashMap<>() ;
                                requestNotification.put("From", currentUserID) ;
                                requestNotification.put("Type", "Request") ;

                                notificaationsReference.child(userID).push().setValue(requestNotification).addOnCompleteListener(new OnCompleteListener<Void>()
                                {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task)
                                    {
                                        if(task.isSuccessful())
                                        {
                                            sendRequestButton.setEnabled(true);
                                            currentState = "sent";
                                            sendRequestButton.setText(R.string.cancel_request);
                                        }

                                    }
                                }) ;
                            }

                        }
                    }) ;
                }

            }
        }) ;
    }

    private void InitializeFields()
    {
        visitProfileImage = findViewById(R.id.visit_profile_image) ;
        visitUsername = findViewById(R.id.visit_profile_username) ;
        visitStatus = findViewById(R.id.visit_profile_status) ;
        sendRequestButton = findViewById(R.id.send_request_button) ;
        declineButton = findViewById(R.id.decline_button) ;
    }
}
