package com.example.chat;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class MessagesAdapter extends RecyclerView.Adapter<MessagesAdapter.MessageViewHolder>
{
    private List<Messages> MessagesList ;

    private FirebaseAuth auth ;
    private DatabaseReference usersReference ;

    public MessagesAdapter(List<Messages> messagesList)
    {
        this.MessagesList = messagesList;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.messages_layout, parent, false) ;

        auth = FirebaseAuth.getInstance() ;
        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MessageViewHolder holder, int position)
    {
        String senderUserID = Objects.requireNonNull(auth.getCurrentUser()).getUid() ;
        Messages messages = MessagesList.get(position) ;

        String from = messages.getFrom() ;
        String type = messages.getType() ;

        usersReference = FirebaseDatabase.getInstance().getReference().child("Users").child(from);

        usersReference.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                String profileImage = null;
                if(dataSnapshot.hasChild("ProfileImage"))
                {
                    profileImage = Objects.requireNonNull(dataSnapshot.child("ProfileImage").getValue()).toString() ;
                }
                Picasso.get().load(profileImage).placeholder(R.drawable.profile_image).into(holder.receiverProfileImage);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });

        if(type.equals("Text"))
        {
            holder.receiverMessage.setVisibility(View.INVISIBLE);
            holder.receiverProfileImage.setVisibility(View.INVISIBLE);
            holder.senderMessage.setVisibility(View.INVISIBLE);
            if(from.equals(senderUserID))
            {
                holder.senderMessage.setVisibility(View.VISIBLE);
                holder.senderMessage.setText(messages.getMessage());
            }
            else
            {
                holder.receiverMessage.setVisibility(View.VISIBLE);
                holder.receiverProfileImage.setVisibility(View.VISIBLE);
                holder.receiverMessage.setText(messages.getMessage());
            }
        }

    }

    @Override
    public int getItemCount()
    {
        if(MessagesList!=null)
            return MessagesList.size() ;
        return 0 ;
    }

    public class MessageViewHolder extends RecyclerView.ViewHolder
    {
        public TextView senderMessage, receiverMessage ;
        public CircleImageView receiverProfileImage ;

        public MessageViewHolder(@NonNull View itemView)
        {
            super(itemView);

            senderMessage = itemView.findViewById(R.id.sender_message) ;
            receiverMessage = itemView.findViewById(R.id.receiver_message) ;
            receiverProfileImage = itemView.findViewById(R.id.receiver_profile_image) ;
        }
    }
}
